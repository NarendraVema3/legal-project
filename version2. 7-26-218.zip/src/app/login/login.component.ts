import { AngularFireModule } from 'angularfire2';
import { LoginService } from './../services/loginDetails.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuthModule } from 'angularfire2/auth';

@Component({
  selector: 'app-login1',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validation: boolean;

  loginDetails:any;


  constructor( private loginsrv:LoginService,private router:Router,private angular:AngularFireAuthModule ) { 
  
     this.loginDetails={
      
      content1:'',
      content2:''


     }
    
           // this.angular.auth()
  }

 

   

  submit( status :boolean )
{      
   

  console.log(status);
  
        this.loginsrv.home(status)


    // this.loginsrv.logindetails(this.loginDetails.content1 , this.loginDetails.content2)
    // .then(data=>
    // {
    //               console.log(data);
    // })
    // .catch(error=>{
    //   console.log(error);
    // })
    // console.log(this.loginDetails);
    

    if( this.loginDetails.content1 == 'linkbiz' && this.loginDetails.content2 == 'lbit' )
    {
    this.router.navigate(["/home"]);
  }
  else{
    this.router.navigate(["/"]);
    this.validation = true;
  }
}


  ngOnInit() {
  }

}
