import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-a',
  templateUrl: './section-a.component.html',
  styleUrls: ['./section-a.component.css']
})
export class SectionAComponent implements OnInit {
  status: string;

  remandsectionA:any;
  constructor( private printSrv:PrintService ) {

     this.remandsectionA={

         content1:'',
         content2:'',
         content3:'',
         content4:'',
         content5:'',
         content6:'',
         content7:'',
         content8:'',
         content9:'',


     }
 
   }

  ngOnInit() {
  }

  sectionAsubmit()
  {
  this.printSrv.RsectionA(this.remandsectionA)
   // console.log(this.remandsectionA);

  }



  cancel()
  {
    this.status = 'submitted';
  }

}
