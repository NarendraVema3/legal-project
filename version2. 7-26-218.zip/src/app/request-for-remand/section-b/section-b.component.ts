import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-b',
  templateUrl: './section-b.component.html',
  styleUrls: ['./section-b.component.css']
})
export class SectionBComponent implements OnInit {
  remandsectionB: any;

  constructor( private printsrv:PrintService ) 
  {


    this.remandsectionB={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
  


  }

   }

  ngOnInit() {
  }


  sectionAsubmit()
  {

  this.printsrv.RsectionB(this.remandsectionB)
   // console.log(this.remandsectionA);

  }

}
