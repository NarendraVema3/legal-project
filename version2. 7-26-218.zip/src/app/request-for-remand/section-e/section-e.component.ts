import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-e',
  templateUrl: './section-e.component.html',
  styleUrls: ['./section-e.component.css']
})
export class SectionEComponent implements OnInit {

  remandsectionE:any;
  constructor( private printsrv:PrintService ) 
  {


    this.remandsectionE={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
      content9:'',


  }

   }

  ngOnInit() {
  }


  sectionEsubmit()
  {

  this.printsrv.RsectionE(this.remandsectionE)
    console.log(this.remandsectionE);

  }

}
