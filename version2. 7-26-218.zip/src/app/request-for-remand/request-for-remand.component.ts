import { Router } from '@angular/router';
import { PrintService } from './../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-for-remand',
  templateUrl: './request-for-remand.component.html',
  styleUrls: ['./request-for-remand.component.css']
})
export class RequestForRemandComponent implements OnInit {
 
   
  requestRemand:any;
  constructor( private printsrv:PrintService ,private router:Router ) {

    this.requestRemand = 
    {

       content1:'',
       content2:'',
       content3:'',
       content4:'',
       content5:'',
       content6:'',
       content7:'',
       

    }

   }




   submitRemand()
   {
     console.log(this.requestRemand);
     this.printsrv.remandrequest(this.requestRemand);
    this.router.navigate(["/remandsectionA"]);
   }

  ngOnInit() {
  }

}
