import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-c',
  templateUrl: './section-c.component.html',
  styleUrls: ['./section-c.component.css']
})
export class SectionCComponent implements OnInit {

  remandsectionC:any;
  constructor( private printsrv:PrintService ) 
  {


    this.remandsectionC={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
      content9:'',


  }

   }

  ngOnInit() {
  }


  sectionCsubmit()
  {

  this.printsrv.RsectionC(this.remandsectionC)
    console.log(this.remandsectionC);

  }

}
