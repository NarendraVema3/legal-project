import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastperson-see',
  templateUrl: './lastperson-see.component.html',
  styleUrls: ['./lastperson-see.component.css']
})
export class LastpersonSeeComponent implements OnInit {

  lastseen:any;
  constructor( private router:Router,private printsrv:PrintService )   
  { 
     this.lastseen={
        
      content1:'',
      content2:'',
      content3:'',
      content4:''
      
     }

   }

  ngOnInit() {
  }

  lastSee()
{

   this.printsrv.reportlastperson(this.lastseen)
  console.log(this.lastseen);

  this.router.navigate(["/Committed"]);
  
}

}
