import { PrintService } from './../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-scene-report',
  templateUrl: './scene-report.component.html',
  styleUrls: ['./scene-report.component.css']
})
export class SceneReportComponent implements OnInit {


  scene:any
  constructor( private router:Router,private printsrv:PrintService ) 
  { 
    this.scene={   
    content1:'',
    content2:'',
    content3:'',
    content4:'',
    content5:'',
    content6:'',
    content7:'',
    content8:'',
    content9:'',
    content10:'',
    content11:'',

  }
  }

  ngOnInit() {
  }

  sceneReport()
{
   this.printsrv.reportScene(this.scene);
   console.log(this.scene);
   this.router.navigate(["/offence"]);

}
}
