import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { MotorVehicalsComponent } from './../motor-vehicals/motor-vehicals.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-committed',
  templateUrl: './committed.component.html',
  styleUrls: ['./committed.component.css']
})
export class CommittedComponent implements OnInit {
  commited: any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {
    this.commited ={

content1:'',
content2:'',
content3:'',
content4:'',
content5:'',
content6:'',
content7:'',
content8:'',
content9:'',
content10:'',
content11:'',
content12:'',
content13:'',
content14:'',
content15:'',
content16:'',
content17:'',
content18:'',
content19:'',
content20:'',
content21:'',
content22:'',
content23:'',
content24:'',
content25:'',
content26:'',
content27:'',
content28:'',
content29:'',
content30:'',
content31:'',
content32:'',
content33:'',
content34:'',
content35:'',
content36:'',
content37:'',
content38:'',
content39:'',
content40:'',
content41:'',
content42:'',
content43:'',
content44:'',
content45:'',
content46:'',
content47:'',
content48:'',
content49:''



   }
  }
  ngOnInit() {
  }



  submitcommit()
  {
  this.printsrv.reportCommit(this.commited)
    console.log(this.commited);
    this.router.navigate(["/sceneprint"]);
  }

}
