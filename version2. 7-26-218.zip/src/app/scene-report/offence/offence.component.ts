import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offence',
  templateUrl: './offence.component.html',
  styleUrls: ['./offence.component.css']
})
export class OffenceComponent implements OnInit {
  offence:any;
  constructor( private router:Router,private printsrv:PrintService ) 
  {

     this.offence={

       content1:'',
       content2:'',
       content3:'',
       content4:'',
       content5:'',
       content6:'',
       content7:''
       
     }

   }

  ngOnInit() {
  }


  offenceReport()
  {
    this.printsrv.reportoffence(this.offence);
     console.log(this.offence);
    this.router.navigate(["/discovered"]);
  }
}
