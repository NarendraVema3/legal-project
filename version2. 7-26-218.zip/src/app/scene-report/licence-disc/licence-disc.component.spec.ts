import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenceDiscComponent } from './licence-disc.component';

describe('LicenceDiscComponent', () => {
  let component: LicenceDiscComponent;
  let fixture: ComponentFixture<LicenceDiscComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LicenceDiscComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenceDiscComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
