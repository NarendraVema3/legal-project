import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-licence-disc',
  templateUrl: './licence-disc.component.html',
  styleUrls: ['./licence-disc.component.css']
})
export class LicenceDiscComponent implements OnInit {

  licence:any;
  constructor( private router:Router,private printsrv:PrintService ) 
  {

       this.licence=
       {
            content1:'',
            content2:'',
            content3:'',
            content4:'',
       }

   }

  ngOnInit() {
  }



  submitlicence()
  { 
      this.printsrv.reportLicence(this.licence);

       this.router.navigate(["/insurance"]);

       this.printsrv.reportLicence(this.licence);
    console.log( this.licence );
  }
}
