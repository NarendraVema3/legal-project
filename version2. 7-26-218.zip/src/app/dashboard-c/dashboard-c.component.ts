import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-c',
  templateUrl: './dashboard-c.component.html',
  styleUrls: ['./dashboard-c.component.css']
})
export class DashboardCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
