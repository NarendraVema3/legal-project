import { Router } from '@angular/router';
import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicaltype',
  templateUrl: './medicaltype.component.html',
  styleUrls: ['./medicaltype.component.css']
})
export class MedicaltypeComponent implements OnInit {
  status: string;
  medicaltype2: any;

  constructor( private printsrv:PrintService,private router:Router ) {

    this.medicaltype2={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
      content9:'',
      content10:''

       
     }


   }

  ngOnInit() {
  }


   medicaltype2submit()
   {
      console.log(this.medicaltype2);

      window.scrollTo(0,1000);
         
      this.status = "Data Submitted";
      this.printsrv.medicaltypetwo(this.medicaltype2);
      setTimeout(() => {
        
       this.router.navigate(['/medicalprint']);
   }, 3000);
   }

}
