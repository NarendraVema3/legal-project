import { Router } from '@angular/router';
import { PrintService } from './../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-report',
  templateUrl: './medical-report.component.html',
  styleUrls: ['./medical-report.component.css']
})
export class MedicalReportComponent implements OnInit {
  medicaltype1: any;

  constructor( private printsrv:PrintService,private router:Router )
   {

             this.medicaltype1={

              content1:'',
              content2:'',
              content3:'',
              content4:''

               
             }

    }

  ngOnInit() {
  }



  type1submit()
  {
      console.log(this.medicaltype1);
      this.printsrv.medicaltypeone(this.medicaltype1);
      this.router.navigate(["/medicalreporttype"]);
  }

}
