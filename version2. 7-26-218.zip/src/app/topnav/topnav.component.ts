import { LoginService } from './../services/loginDetails.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.css']
})
export class TopnavComponent implements OnInit {
  scene: any;
  reportrecord: any;
  medical:any;
  requestRemand: any;
  login: any;
  viewmode:'map'; 

  stolenProperty:any

  constructor(private service:LoginService,private router:Router) { 
 

    console.log(this.viewmode);

   this.stolenProperty=[
     { name:'stolen property',path:"/stolenproperty" },
     { name:'owner/custodian',path:"/stolenOwner" }
    ]

    this.requestRemand=[
      { name:'request  remand',path:"/requestforremand" },
      { name:'section a',path:"/remandsectionA" },
      { name:'section b',path:"/remandsectionB" },
      { name:'section c',path:"/remandsectionC" },
      { name:'section d',path:"/remandsectionD" },
      { name:'section e',path:"/remandsectionE" }
     ]


    this.medical=[
      { name:'medical report',path:"/medicalreport" },
      { name:'medical type',path:"/medicalreporttype" }
     ]


     this.reportrecord = [
      { name:'report record',path:"/recordreport" },
      { name:'accused',path:"/accused" },
      { name:'complainant',path:"/complainant" },
      { name:'details',path:"/details" },
      { name:'exhibits',path:"/exhibits" },
      { name:'filing',path:"/filing" },
      { name:'witness',path:"/witness" },       
     ]
     this.scene = [
      { name:'scenereport ',path:"/scenereport" },
      { name:'offence',path:"/offence" },
      { name:'discovered',path:"/discovered" },    
      { name:'StolenProperty',path:"/StolenPropertyR" },
      { name:'motorvehicals',path:"/motorvehicals" },
      { name:'licence',path:"/licence" },
      { name:'wheels',path:"/wheels" },  
      { name:'cycles',path:"/cycles" },
      { name:'LastPerson',path:"/lastperson" },            
      { name:'insurance',path:"/insurance" },     
      { name:'witness',path:"/witness" },
      { name:'instruction',path:"/instruction" },
      { name:'Committed',path:"/Committed" },
     ]

                   this.login = this.service.detail
                   console.log(this.login);
  }




  logout()
  {
         this.router.navigate(["/"]);
  }



  ngOnInit() {
  }



}
