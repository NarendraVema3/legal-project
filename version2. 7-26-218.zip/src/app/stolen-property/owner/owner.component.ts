import { Router } from '@angular/router';
import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-owner',
  templateUrl: './owner.component.html',
  styleUrls: ['./owner.component.css']
})
export class OwnerComponent implements OnInit {
  status: string;
   load = false;
   stolenowner:any;
  constructor( private printsrv:PrintService,private router:Router ) 
  {
           this.stolenowner={

             content1:'',
             content2:'',
             content3:'',
             content4:'',
             content5:'',
             content6:'',
             content7:'',
             content8:'',
             content9:'',
             content10:'',
             content11:'',
             content12:'',
             content13:'',

           }
   }

   
  

  ngOnInit() {
  }

   ownersubmit()
   {
         console.log( this.stolenowner );  
         this.load=true;

         window.scrollTo(0,1000);
         
         this.status = "Data Submitted";
         this.printsrv.stolenowner(this.stolenowner);
         setTimeout(() => {
           
          this.router.navigate(['/stolenprint']);
      }, 3000);
   }
}
