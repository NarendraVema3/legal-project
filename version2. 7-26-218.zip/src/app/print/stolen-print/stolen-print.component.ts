import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-stolen-print',
  templateUrl: './stolen-print.component.html',
  styleUrls: ['./stolen-print.component.css']
})
export class StolenPrintComponent implements OnInit {
  owner: any;
  stolen: any;

  constructor( private printsrv:PrintService,private router:Router ) { }


  cancel()
  {
   this.router.navigate(["/stolenproperty"]);
  }



  ngOnInit() {


    this.stolen = this.printsrv.stolenlist;
    this.owner = this.printsrv.ownerstolen;

  }

}
