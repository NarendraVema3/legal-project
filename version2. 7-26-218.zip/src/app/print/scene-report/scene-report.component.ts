import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scene-report',
  templateUrl: './scene-report.component.html',
  styleUrls: ['./scene-report.component.css']
})
export class SceneReportPrintComponent implements OnInit {
  scene: any;
  person: any;
  moto: any;
  offence: any;
  licence: any;
  insurance: any;
  instruction: any;
  discover: any;
  cycle: any;
  commit: any;
  wheels:any;
  constructor(private service: PrintService) { }

  ngOnInit() {

    this.commit = this.service.commitPrint;

    console.log(this.commit);
    this.cycle = this.service.cyclePrint;
    console.log(this.cycle);
    this.discover = this.service.discoverdPrint;
 console.log(this.discover);
   this.instruction = this.service.instructionPrint;

      this.insurance =     this.service.insurancePrint;

     this.licence =   this.service.licencePrint;
 this.offence =  this.service.offencePrint;
 
 this.moto = this.service.motorPrint;
this.person = this.service.personPrint;
this.scene = this.service.scenePrint;

this.wheels = this.service.wheelsPrint;
console.log(this.wheels);
  }

}

    