import { PrintService } from './../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-record-report',
  templateUrl: './record-report.component.html',
  styleUrls: ['./record-report.component.css']
})
export class RecordReportComponent implements OnInit {
  reportrecord: any;

  constructor(private router: Router ,private printsrv:PrintService) {
    this.reportrecord = {

      content1: '',
      content2: '',
      content3: '',
      content4: '',
      content5: '',
      content6: '',
      content7: '',
      content8: '',
      content9: '',
      content10: '',
      content11: '',
      content12: '',
      content13: '',
      content14: '',
      content15: '',
      content16: ''
    



    }
  }

  ngOnInit() {




  }



  recordreport() {
    console.log(this.reportrecord);
    this.printsrv.recordreport(this.reportrecord);
    this.router.navigate(["/accused"]);
  }
}
