import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exhibits',
  templateUrl: './exhibits.component.html',
  styleUrls: ['./exhibits.component.css']
})
export class ExhibitsComponent implements OnInit {
  exhibitsOfRecord: any;

  constructor( private router:Router,private printsrv:PrintService) { 

    this.exhibitsOfRecord = 
    {
     
        content1:'',
        content2:'',
        content3:''
       
         
    }


  }

  ngOnInit() {
  }

  exhibits()
  {
    console.log(this.exhibitsOfRecord);
    this.printsrv.recordexhibits(this.exhibitsOfRecord);
    this.router.navigate(["/reportprint"]);
  }


}
