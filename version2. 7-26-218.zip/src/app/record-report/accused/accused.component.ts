import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accused',
  templateUrl: './accused.component.html',
  styleUrls: ['./accused.component.css']
})
export class AccusedComponent implements OnInit {
  accuse: any;

  constructor( private router:Router ,private printsrv:PrintService ) 
  {
               this.accuse={
              
                content1:'',
                content2:'',
                content3:'',
                content4:'',
                content5:'',
                content6:'',
                content7:'',
                content8:'',
                content9:'',
                content10:'',
                content11:'',
                content12:'',

                

               }

   }

  ngOnInit() {
  }


  accused()
{
          console.log(this.accuse);
          this.printsrv.recordaccused(this.accuse);
         this.router.navigate(["/complainant"]);
}

}
