import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-witness',
  templateUrl: './witness.component.html',
  styleUrls: ['./witness.component.css']
})
export class WitnessComponent implements OnInit {
  witnessOfRecord: any;

  constructor( private router:Router , private printsrv:PrintService) 
  {
               this.witnessOfRecord =
               {
                 content1:'',
                 content2:''
               }


   }

  ngOnInit() {
  }

  witness()
  {
              console.log(this.witnessOfRecord);
              this.printsrv.recordwitness(this.witnessOfRecord);
             this.router.navigate(["/exhibits"]);
  }  

}
