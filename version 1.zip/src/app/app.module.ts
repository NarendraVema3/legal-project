import { SceneReportPrintComponent } from './print/scene-report/scene-report.component';
import { InstructionComponent } from './scene-report/instruction/instruction.component';
import { environment } from './../environments/environment';

import { PrintService } from './services/print.service';
import { StolenPrintComponent } from './print/stolen-print/stolen-print.component';
import { LoginService } from './services/loginDetails.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { AngularFireModule } from 'angularfire2';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { RoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopnavComponent } from './topnav/topnav.component';
import { RecordReportComponent } from './record-report/record-report.component';
import { StolenPropertyComponent } from './stolen-property/stolen-property.component';
import { RequestForRemandComponent } from './request-for-remand/request-for-remand.component';
import { SceneReportComponent } from './scene-report/scene-report.component';
import { MedicalReportComponent } from './medical-report/medical-report.component';
import { AccusedComponent } from './record-report/accused/accused.component';
import { ComplainantComponent } from './record-report/complainant/complainant.component';
import { DetailsComponent } from './record-report/details/details.component';
import { FilingComponent } from './record-report/filing/filing.component';
import { WitnessComponent } from './record-report/witness/witness.component';
import { ExhibitsComponent } from './record-report/exhibits/exhibits.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';

import { OwnerComponent } from './stolen-property/owner/owner.component';
import { SectionAComponent } from './request-for-remand/section-a/section-a.component';
import { SectionBComponent } from './request-for-remand/section-b/section-b.component';
import { SectionCComponent } from './request-for-remand/section-c/section-c.component';
import { SectionDComponent } from './request-for-remand/section-d/section-d.component';
import { SectionEComponent } from './request-for-remand/section-e/section-e.component';
import { MedicaltypeComponent } from './medical-report/medicaltype/medicaltype.component';
import { PersonDetailsComponent } from './scene-report/person-details/person-details.component';
import { RequestRemandPrintComponent } from './print/request-remand-print/request-remand-print.component';
import {MatIconModule} from '@angular/material/icon';
import { MedicalComponent } from './print/medical/medical.component';
import { ReportprintComponent } from './print/reportprint/reportprint.component';
import { DiscoveredComponent } from './scene-report/discovered/discovered.component';
import { OffenceComponent } from './scene-report/offence/offence.component';
import { MotorVehicalsComponent } from './scene-report/motor-vehicals/motor-vehicals.component';
import { LicenceDiscComponent } from './scene-report/licence-disc/licence-disc.component';
import { InsuranceCompanyComponent } from './scene-report/insurance-company/insurance-company.component';
import { CyclesComponent } from './scene-report/cycles/cycles.component';
import { StolenPropertyRComponent } from './scene-report/stolen-property/stolen-property.component';
import { WheelsComponent } from './scene-report/wheels/wheels.component';
import { LastpersonSeeComponent } from './scene-report/lastperson-see/lastperson-see.component';
import { CommittedComponent } from './scene-report/committed/committed.component';
import { LayoutComponent } from './layout/layout.component';
import { HomeComponent } from './home/home.component';
import { DashboardCComponent } from './dashboard-c/dashboard-c.component';


@NgModule({
  declarations: [
    AppComponent,
    TopnavComponent,
    RecordReportComponent,
    StolenPropertyComponent,
    RequestForRemandComponent,
    SceneReportComponent,
    MedicalReportComponent,
    AccusedComponent,
    ComplainantComponent,
    DetailsComponent,
    FilingComponent,
    WitnessComponent,
    ExhibitsComponent,
    LoginComponent,
    OwnerComponent,
    SectionAComponent,
    SectionBComponent,
    SectionCComponent,
    SectionDComponent,
    SectionEComponent,
    MedicaltypeComponent,
    PersonDetailsComponent,
    RequestRemandPrintComponent,
    StolenPrintComponent,
    MedicalComponent,
    ReportprintComponent,
    DiscoveredComponent,
    OffenceComponent,
    MotorVehicalsComponent,
    LicenceDiscComponent,
    InsuranceCompanyComponent,
    CyclesComponent,
    StolenPropertyRComponent,
    WheelsComponent,
    LastpersonSeeComponent,
    CommittedComponent,
    LayoutComponent,
    InstructionComponent,
    SceneReportPrintComponent,
    HomeComponent,
    DashboardCComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
   AngularFireAuthModule,
    MatProgressSpinnerModule,
    RoutingModule
  ],
  providers: [LoginService, PrintService],
  bootstrap: [AppComponent]
})
export class AppModule { }
