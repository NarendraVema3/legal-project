import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-section-d',
  templateUrl: './section-d.component.html',
  styleUrls: ['./section-d.component.css']
})
export class SectionDComponent implements OnInit {


  remandsectionD:any;
  constructor( private printsrv:PrintService ) 
  {


    this.remandsectionD={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
    


  }

   }

  ngOnInit() {
  }


  sectionDsubmit()
  {

  this.printsrv.RsectionD(this.remandsectionD)
    console.log(this.remandsectionD);

  }

}
