import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestForRemandComponent } from './request-for-remand.component';

describe('RequestForRemandComponent', () => {
  let component: RequestForRemandComponent;
  let fixture: ComponentFixture<RequestForRemandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestForRemandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestForRemandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
