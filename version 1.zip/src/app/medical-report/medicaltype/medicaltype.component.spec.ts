import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicaltypeComponent } from './medicaltype.component';

describe('MedicaltypeComponent', () => {
  let component: MedicaltypeComponent;
  let fixture: ComponentFixture<MedicaltypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicaltypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicaltypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
