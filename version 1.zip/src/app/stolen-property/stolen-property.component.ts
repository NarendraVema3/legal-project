import { LoginService } from './../services/loginDetails.service';
import { Router } from '@angular/router';
import { PrintService } from './../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stolen-property',
  templateUrl: './stolen-property.component.html',
  styleUrls: ['./stolen-property.component.css']
})
export class StolenPropertyComponent implements OnInit {
  statuscheck: any;
  status: string;
  stolen: any;

 


  constructor( private printsrv:PrintService,private router:Router,private service:LoginService) 
  {
        this.stolen={          
          content1:'',
          content2:'',
          content3:'',
          content4:'',
          content5:'',
          content6:''
        }
    
    }

  ngOnInit() {

    this.statuscheck = this.service.login
  }

  stolensubmit()
{
  //console.log(this.stolen)
  this.printsrv.stolenlist(this.stolen);
  this.status = 'Data Submitted';
  this.router.navigate(["/stolenOwner"]);
 
  
}


}
