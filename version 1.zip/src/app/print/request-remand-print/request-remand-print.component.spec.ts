import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestRemandPrintComponent } from './request-remand-print.component';

describe('RequestRemandPrintComponent', () => {
  let component: RequestRemandPrintComponent;
  let fixture: ComponentFixture<RequestRemandPrintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestRemandPrintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestRemandPrintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
