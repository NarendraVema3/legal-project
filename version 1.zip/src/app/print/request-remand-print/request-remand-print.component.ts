import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-request-remand-print',
  templateUrl: './request-remand-print.component.html',
  styleUrls: ['./request-remand-print.component.css']
})
export class RequestRemandPrintComponent implements OnInit {
  RsectionE: any;
  RsectionD: any;
  RsectionC: any;
  RsectionB: any;
  RsectionA: any;
  Rsection: any;
  remandRequest:any;
  constructor( private printsrc:PrintService,private router:Router) 
  {

     


   }

cancel()
{
   this.router.navigate(["/requestforremand"]);
}


  ngOnInit() {
    this.RsectionA = this.printsrc.remandSectionA;

    console.log(this.RsectionA);
    
    this.RsectionB = this.printsrc.remandSectionB;
    console.log(this.RsectionB);

    this.RsectionC = this.printsrc.remandSectionC;

    console.log(this.RsectionC);

    this.RsectionD = this.printsrc.remandSectionD;

    console.log(this.RsectionD);

    this.RsectionE = this.printsrc.remandSectionE;
   console.log('enter');
   console.log(this.RsectionE);
   
  this.remandRequest = this.printsrc.remandRequest;

    
  console.log(this.remandRequest);
  }


}
