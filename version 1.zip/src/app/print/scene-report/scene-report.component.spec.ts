import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SceneReportComponent } from './scene-report.component';

describe('SceneReportComponent', () => {
  let component: SceneReportComponent;
  let fixture: ComponentFixture<SceneReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SceneReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SceneReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
