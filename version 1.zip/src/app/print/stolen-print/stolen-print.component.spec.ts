import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StolenPrintComponent } from './stolen-print.component';

describe('StolenPrintComponent', () => {
  let component: StolenPrintComponent;
  let fixture: ComponentFixture<StolenPrintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StolenPrintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StolenPrintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
