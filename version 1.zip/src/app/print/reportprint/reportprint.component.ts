import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportprint',
  templateUrl: './reportprint.component.html',
  styleUrls: ['./reportprint.component.css']
})
export class ReportprintComponent implements OnInit {
  complainant:any;
  witness:any;
  filing: any;
  exhibits:any;
  details: any;
  accused:any;
  recordreport: any;

  constructor( private printsrv:PrintService ) { }

  ngOnInit() {


    this.recordreport =  this.printsrv.reportrecord;
     this.accused =  this.printsrv.reportaccused;
      this.details =  this.printsrv.reportdetails;
     
      // console.log(this.details);
     
      this.exhibits =   this.printsrv.reportexhibits;

      console.log(this.exhibits);
       this.filing =   this.printsrv.reportfiling;
       console.log(this.filing);
       this.witness = this.printsrv.reportwitness;
       console.log(this.witness);    
       this.complainant =   this.printsrv.reportcomplainant;


  }

}
