import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medical',
  templateUrl: './medical.component.html',
  styleUrls: ['./medical.component.css']
})
export class MedicalComponent implements OnInit {
  type2: any;
  type1: any;

  constructor( private printsrv:PrintService,private router:Router ) { }

  ngOnInit() {


   this.type1 =  this.printsrv.medicaltype1;
   this.type2 =  this.printsrv.medicaltype2;
  }

  cancel()
  {
   this.router.navigate(["/medicalreport"]);
  }

}
