import { Injectable } from '@angular/core';
import * as firebase from 'firebase/app';


@Injectable()

export class LoginService
{
 
  
    detail=[];
       login:any;
       status:string;
    constructor(  )
    {

    }

     logindetails(email:any,password:any)
     { 
      //      return    firebase.auth().signInWithEmailAndPassword(email,password);
               console.log('enter');

           return new Promise<any>((resolve, reject) => {
            firebase.auth().signInWithEmailAndPassword(email,password)
            .then(res => {
              resolve(res);
            }, err => reject(err))
          })

           // console.log(details);

            //this.home(details);
            //this.login = details;

          // console.log(this.login);
     }

     home(status)
     {
          
        this.login = status;

        console.log(status);
                    
     }


}