import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()

export class PrintService {
    stolenPrint: any;
    lastpersonPrint: any;
    wheelsPrint: any;
    offencePrint: any;
    motorPrint: any;
    licencePrint: any;
    personPrint: any;
    insurancePrint: any;
    instructionPrint: any;
    discoverdPrint: any;
    cyclePrint: any;
    commitPrint: any;
    scenePrint: any;
    
    reportwitness: any;
    reportfiling: any;
    reportexhibits: any;
    reportdetails: any;
    reportcomplainant: any;
   
    reportaccused: any;
    reportrecord: any;
    medicaltype2: any;
    medicaltype1: any;
    ownerstolen: any;

    remandSectionA = [];
    remandRequest = [];
    remandSectionB: any;
    remandSectionC: any;
    remandSectionD: any;
    remandSectionE: any;

    constructor(private router: Router) {


    }


    RsectionA(sectionA) {

        this.remandSectionA = sectionA;
        console.log(this.remandSectionB);

        this.router.navigate(["/remandsectionB"]);


    }


    RsectionB(sectionB) {

        this.remandSectionB = sectionB;
        console.log(this.remandSectionB);

        this.router.navigate(["/remandsectionC"]);


    }
    RsectionC(sectionC) {

        this.remandSectionC = sectionC;
        console.log(this.remandSectionC);

        this.router.navigate(["/remandsectionD"]);


    }
    RsectionD(sectionD) {

        this.remandSectionD = sectionD;
        console.log(this.remandSectionD);

        this.router.navigate(["/remandsectionE"]);


    }

    RsectionE(sectionE) {

        this.remandSectionE = sectionE;
        console.log(this.remandSectionE);

        this.router.navigate(["/requestremand"]);


    }

    remandrequest(remand) {
        this.remandRequest = remand;
        console.log(this.remandRequest);
    }


    stolenlist(stolen) {
        this.stolenlist = stolen;
    }

    stolenowner(owner) {
        this.ownerstolen = owner;
    }

    medicaltypeone(typeone) {
        this.medicaltype1 = typeone;
    }
    medicaltypetwo(typetwo) {
        this.medicaltype2 = typetwo;
    }

    recordreport(report) {

         console.log(report);
        this.reportrecord =  report;



    }

    recordaccused(accused) {
  console.log(accused);
        this.reportaccused =  accused;

    }

    recoredcomplainant( complainant ) {

         console.log(complainant);
        this.reportcomplainant=  complainant;

    }
    recorddetails( details ) {
        
        console.log(details);
        this.reportdetails =  details;

    }
    recordexhibits( exhibits ) {
        console.log(exhibits);
        this.reportexhibits =  exhibits;
    }
    recordfiling( filing ) {
         console.log(filing);
        this.reportfiling =  filing;

    }

    recordwitness( witness ) {
          console.log(witness);
        this.reportwitness =  witness;

    }




    reportScene( scene )
    {
            this.scenePrint = scene;
    }


    reportCommit( commit )
    {
            this.commitPrint = commit;
    }
    reportCycle( cycle )
    {
            this.cyclePrint = cycle;
    }
    reportDiscoverd( discoverd )
    {
            this.discoverdPrint = discoverd;
    }
    reportinstruction( instruction )
    {
            this.instructionPrint = instruction;
    }
    reportInsurance( insurance )
    {
            this.insurancePrint = insurance;
    }
    reportlastperson( person )
    {
            this.personPrint = person;
    }
    reportLicence( licence )
    {
            this.licencePrint = licence;
    }
    reportMotor( motor )
    {
            this.motorPrint = motor;
    }
    reportoffence( offence )
    {
            this.offencePrint = offence;
    }

    reportwheels( wheels )
    {
            this.wheelsPrint = wheels;
    }
    reportstolen( stolen )
    {
            this.stolenPrint = stolen;
    }

}