import { DashboardCComponent } from './dashboard-c/dashboard-c.component';
import { HomeComponent } from './home/home.component';
import { SceneReportPrintComponent } from './print/scene-report/scene-report.component';
import { InstructionComponent } from './scene-report/instruction/instruction.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TopnavComponent } from './topnav/topnav.component';
import { RecordReportComponent } from './record-report/record-report.component';
import { StolenPropertyComponent } from './stolen-property/stolen-property.component';
import { RequestForRemandComponent } from './request-for-remand/request-for-remand.component';
import { SceneReportComponent } from './scene-report/scene-report.component';
import { MedicalReportComponent } from './medical-report/medical-report.component';
import { AccusedComponent } from './record-report/accused/accused.component';
import { ComplainantComponent } from './record-report/complainant/complainant.component';
import { DetailsComponent } from './record-report/details/details.component';
import { FilingComponent } from './record-report/filing/filing.component';
import { WitnessComponent } from './record-report/witness/witness.component';
import { ExhibitsComponent } from './record-report/exhibits/exhibits.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';

import { OwnerComponent } from './stolen-property/owner/owner.component';
import { SectionAComponent } from './request-for-remand/section-a/section-a.component';
import { SectionBComponent } from './request-for-remand/section-b/section-b.component';
import { SectionCComponent } from './request-for-remand/section-c/section-c.component';
import { SectionDComponent } from './request-for-remand/section-d/section-d.component';
import { SectionEComponent } from './request-for-remand/section-e/section-e.component';
import { MedicaltypeComponent } from './medical-report/medicaltype/medicaltype.component';
import { PersonDetailsComponent } from './scene-report/person-details/person-details.component';
import { RequestRemandPrintComponent } from './print/request-remand-print/request-remand-print.component';
import {MatIconModule} from '@angular/material/icon';
import { MedicalComponent } from './print/medical/medical.component';
import { ReportprintComponent } from './print/reportprint/reportprint.component';
import { DiscoveredComponent } from './scene-report/discovered/discovered.component';
import { OffenceComponent } from './scene-report/offence/offence.component';
import { MotorVehicalsComponent } from './scene-report/motor-vehicals/motor-vehicals.component';
import { LicenceDiscComponent } from './scene-report/licence-disc/licence-disc.component';
import { InsuranceCompanyComponent } from './scene-report/insurance-company/insurance-company.component';
import { CyclesComponent } from './scene-report/cycles/cycles.component';
import { StolenPropertyRComponent } from './scene-report/stolen-property/stolen-property.component';
import { WheelsComponent } from './scene-report/wheels/wheels.component';
import { LastpersonSeeComponent } from './scene-report/lastperson-see/lastperson-see.component';
import { CommittedComponent } from './scene-report/committed/committed.component';
import { LayoutComponent } from './layout/layout.component';
import { StolenPrintComponent } from './print/stolen-print/stolen-print.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path:'',component: LayoutComponent,
    children :[
    
  {
    path:'stolenproperty',component: StolenPropertyComponent
  },
  {
       path:'stolenOwner',component:OwnerComponent    
  },
  {
    path:'remandsectionA',component:SectionAComponent
  },
  {
    path:'remandsectionB',component:SectionBComponent
  },
  {
    path:'remandsectionC',component:SectionCComponent
  },
  {
    path:'remandsectionD',component:SectionDComponent
  },
  {
    path:'remandsectionE',component:SectionEComponent
  },
 
  {
    path:'medicalreport',component:MedicalReportComponent
  },
  {
    path:'medicalreporttype',component:MedicaltypeComponent
  },
  {
    path:'scenereport',component:SceneReportComponent
  },
  {
    path:'persondetails',component:PersonDetailsComponent
  },
  {
    path:'stolenprint',component:StolenPrintComponent
  },
  {
    path:'requestremand',component:RequestRemandPrintComponent
  },
  {
    path:'requestforremand',component:RequestForRemandComponent
  },
  {
    path:'recordreport',component:RecordReportComponent
  },
  {
    path:'SceneReport2',component:SceneReportComponent
  },
  {
    path:'medicalprint',component:MedicalComponent
  },
  {
    path:'accused',component:AccusedComponent
  },
  {
    path:'complainant',component:ComplainantComponent
  },
  {
    path:'filing',component:FilingComponent
  },
  {
    path:'witness',component:WitnessComponent
  },
  {
    path:'exhibits',component:ExhibitsComponent
  },
  {
    path:'reportprint',component:ReportprintComponent
  },
  {
    path:'cycles',component:CyclesComponent
  },
  {
    path:'discovered',component:DiscoveredComponent
  },
  {
    path:'insurance',component:InsuranceCompanyComponent
  },
  {
    path:'licence',component:LicenceDiscComponent
  },
  {
    path:'motorvehicals',component:MotorVehicalsComponent
  },
  {
    path:'offence',component:OffenceComponent
  },
  {
    path:'StolenPropertyR',component:StolenPropertyRComponent
  },
  {
    path:'wheels',component:WheelsComponent
  },
  {
    path:'lastperson',component:LastpersonSeeComponent
  },
  {
    path:'Committed',component:CommittedComponent
  },
  {
    path:'instruction',component:InstructionComponent
  },
  {
    path:'sceneprint',component:SceneReportPrintComponent
  },
  {
    path:'details',component:DetailsComponent
  },
  {
    path:'home',component:HomeComponent
  },
  {
    path:'dashboardC',component:DashboardCComponent
  }
]
  }
];    


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class RoutingModule { }
