import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  detailsOfRecord: any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {
    this.detailsOfRecord = 
    {
     
        content1:'',
        content2:'',
        content3:'',
        content4:'',                   
        content5:'',
        content6:'',
        content7:'',
        content8:'',
        content9:'',
        content10:'',
         
    }


   }

  ngOnInit() {
  }

  details()
  {
      console.log(this.detailsOfRecord);
      this.printsrv.recorddetails(this.detailsOfRecord);
      this.router.navigate(["/filing"]);
  }

}
