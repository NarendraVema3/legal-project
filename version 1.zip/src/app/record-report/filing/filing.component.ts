import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filing',
  templateUrl: './filing.component.html',
  styleUrls: ['./filing.component.css']
})
export class FilingComponent implements OnInit {
  filingOfRecord: any;

  constructor(private router: Router,private printsrv:PrintService) {
    this.filingOfRecord =
      {
            content1:'',
            content2:'',
            content3:'',
            content4:'',
            content5:''

      }

  }

  ngOnInit() {
  }


  filing() {
    console.log(this.filingOfRecord);
    this.printsrv.recordfiling(this.filingOfRecord);
    this.router.navigate(["/witness"]);
  }

}
