import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-complainant',
  templateUrl: './complainant.component.html',
  styleUrls: ['./complainant.component.css']
})
export class ComplainantComponent implements OnInit {
  complainant1: any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {
               this.complainant1 = 
               {
                
                   content1:'',
                   content2:'',
                   content3:'',
                   content4:'',                   
                   content5:'',
                   content6:'',
                   content7:'',
                   content8:'',
                   content9:'',
                   content10:'',
                    
               }

   }

  ngOnInit() {
  }


  complainant()
  { 
               console.log(this.complainant1); 
               this.printsrv.recoredcomplainant(this.complainant1);
             this.router.navigate(["/details"]);
  }

}
