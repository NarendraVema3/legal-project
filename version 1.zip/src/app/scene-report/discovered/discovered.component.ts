import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discovered',
  templateUrl: './discovered.component.html',
  styleUrls: ['./discovered.component.css']
})
export class DiscoveredComponent implements OnInit {
  discoverd: any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {

    this.discoverd =
    {
 
      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
      content9:'',
      content10:''
    }

   }

  ngOnInit() {
  }



  submitdiscoverd()
{
  this.printsrv.reportDiscoverd(this.discoverd);
  console.log(this.discoverd);
  this.router.navigate(["/StolenPropertyR"]);
}


}
