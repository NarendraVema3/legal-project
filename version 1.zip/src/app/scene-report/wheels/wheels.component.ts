import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wheels',
  templateUrl: './wheels.component.html',
  styleUrls: ['./wheels.component.css']
})
export class WheelsComponent implements OnInit {


  wheels:any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {


    this.wheels={
    content1:'',
    content2:'',  
    content3:'',
    content4:'',
    content5:'',
    content6:'',
    content7:'',
   
  

  }
   }

  ngOnInit() {
  }



  wheelsReport()
{
 
 this.printsrv.reportwheels(this.wheels);
  console.log(this.wheels);
            this.router.navigate(["/cycles"]);
}


}
