import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instruction',
  templateUrl: './instruction.component.html',
  styleUrls: ['./instruction.component.css']
})
export class InstructionComponent implements OnInit {

  instruction:any;

  constructor()
   {
                this.instruction = 
                {
                  content1:'',
                  content2:'',
                  content3:'',
                  content4:'',
                  content5:'',
                  content6:'',
                  content7:'',
                  content8:'',
                  content9:'',
                  content10:'',
                  content11:'',
                  content12:'',
                

                }

    }

  ngOnInit() {
  }


  submitinstruction()
  {
        console.log(this.instruction);
  }


}
