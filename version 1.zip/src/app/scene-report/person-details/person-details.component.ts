import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person-details',
  templateUrl: './person-details.component.html',
  styleUrls: ['./person-details.component.css']
})
export class PersonDetailsComponent implements OnInit {



  person:any;
  constructor( private router:Router,private printsrv:PrintService ) 
  {

     this.person =
     {
       content1:'',
       content2:'',
       content3:'',
       content4:'',
       content5:'',
       content6:'',
       content7:'',
       content8:'',
     }

   }

  ngOnInit() {
  }


  submitperodetails()
  {
    console.log(this.person);
      
  }

}
