import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommittedComponent } from './committed.component';

describe('CommittedComponent', () => {
  let component: CommittedComponent;
  let fixture: ComponentFixture<CommittedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommittedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommittedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
