import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-company',
  templateUrl: './insurance-company.component.html',
  styleUrls: ['./insurance-company.component.css']
})
export class InsuranceCompanyComponent implements OnInit {

  insurance:any;
  constructor( private router:Router,private printsrv: PrintService  ) 
  {
                 this.insurance = 
                 {
                   content1:'',
                   content2:'',
                   content3:'',
                   content4:'',
                   content5:'',
                   content6:'',
                   content7:'',
                   content8:'',
                   content9:'',
                   content10:'',
                   content11:'',
                   content12:'',
                   content13:'',
                   content14:'',
                   content15:'',
                   content16:'',
                 }
        

   }

  ngOnInit() {
  }

submitinstruction()
{
     this.printsrv.reportInsurance(this.insurance);
    console.log(this.insurance);

  this.router.navigate(["/wheels"]);
}




}
