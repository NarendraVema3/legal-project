import { PrintService } from './../../services/print.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cycles',
  templateUrl: './cycles.component.html',
  styleUrls: ['./cycles.component.css']
})
export class CyclesComponent implements OnInit {


  cycle:any;

  constructor( private router:Router,private printsrv:PrintService ) 
  {

    this.cycle ={

      content1:'',
      content2:'',
      content3:'',
      content4:'',
      content5:'',
      content6:'',
      content7:'',
      content8:'',
      content9:'',
      content10:'',
      content11:'',
      content12:'',
      content13:'',
      content14:'',
      content15:'',
      content16:'',
      content17:'',
      content18:'',
      content19:'',

   }
  }
  ngOnInit() {
  }

  cyclesubmit ()
  {
    this.printsrv.reportCycle(this.cycle);
    console.log(this.cycle);
    this.router.navigate(["/lastperson"]);
  }
}
