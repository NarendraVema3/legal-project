import { PrintService } from './../../services/print.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-stolen-property',
  templateUrl: './stolen-property.component.html',
  styleUrls: ['./stolen-property.component.css']
})
export class StolenPropertyRComponent implements OnInit {


  stolen:any;
  constructor( private router:Router,private printsrv:PrintService   ) 
  {

    this.stolen={
    content1:'',
    content2:'',
    content3:'',
    content4:'',
    content5:'',
    content6:'',
    content7:''



   }
  }
  ngOnInit() {

  }

  stolenReport()
{
         this.printsrv.reportstolen(this.stolen);         
          console.log(this.stolen);
          this.router.navigate(["/motorvehicals"]);
}
}
