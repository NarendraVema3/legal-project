import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StolenPropertyComponent } from './stolen-property.component';

describe('StolenPropertyComponent', () => {
  let component: StolenPropertyComponent;
  let fixture: ComponentFixture<StolenPropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StolenPropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StolenPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
