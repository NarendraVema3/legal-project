import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorVehicalsComponent } from './motor-vehicals.component';

describe('MotorVehicalsComponent', () => {
  let component: MotorVehicalsComponent;
  let fixture: ComponentFixture<MotorVehicalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotorVehicalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorVehicalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
