import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastpersonSeeComponent } from './lastperson-see.component';

describe('LastpersonSeeComponent', () => {
  let component: LastpersonSeeComponent;
  let fixture: ComponentFixture<LastpersonSeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastpersonSeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastpersonSeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
